#include "StdAfx.h"
#include "SimpleWall_EM.h"

SimpleWall_EM::SimpleWall_EM(void): ElementMap(ElementMap::SimpleWall)
{
}

SimpleWall_EM::~SimpleWall_EM(void)
{
}
