#include "StdAfx.h"
#include "ElementMap.h"

ElementMap::ElementMap(int pType)
{
	type=pType;
}

void ElementMap::setType(int pType)
{
	type=pType;
}

int ElementMap::getType()
{
	return type;
}
