#include "StdAfx.h"
#include "Ground_EM.h"

Ground_EM::Ground_EM(void) : ElementMap(ElementMap::Ground)
{

};

Ground_EM::~Ground_EM(void)
{
};
