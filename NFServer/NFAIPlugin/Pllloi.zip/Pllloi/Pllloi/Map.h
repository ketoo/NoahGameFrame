#pragma once
#include <vector>
#include "ElementMap.h"
class Map
{
public:
	/**
	*	Etat de la Map
	*/
	enum MapState { EMPTY_MAP, GENERATED_MAP, LOADED_MAP };

	/**
	* Map Generation
	*/
	bool generateMap ();
	ElementMap getElementMap(int x, int y);
	Map(int width,int height);
	~Map(void);
	int getWidth(){return width;};
	int getHeight(){return height;};
private:
	/**
	 * Size of the Map
	 */
	int width,height;
	std::vector<ElementMap> elementsMap;
	int state;

};
