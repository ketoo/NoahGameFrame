#include "StdAfx.h"
#include "MapImageFactory.h"

MapImageFactory::MapImageFactory(void)
{
}

MapImageFactory::~MapImageFactory(void)
{
}
