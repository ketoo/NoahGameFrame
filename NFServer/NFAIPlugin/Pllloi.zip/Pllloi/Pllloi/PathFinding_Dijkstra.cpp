#include "StdAfx.h"
#include "PathFinding_Dijkstra.h"


PathFinding_Dijkstra::PathFinding_Dijkstra(MPoint &pStart, MPoint &pGoal, Map &pmap ) : PathFinding(pStart,pGoal,pmap)
{
}

PathFinding_Dijkstra::~PathFinding_Dijkstra(void)
{
}

MPoint* PathFinding_Dijkstra::calculate()
{
	/*
function Dijkstra(Graph, source):
 2     for each vertex v in Graph:           // Initializations
 3         dist[v] := infinity               // Unknown distance function from s to v
 4         previous[v] := undefined
 5     dist[source] := 0                     // Distance from s to s
 6     Q := copy(Graph)                      // Set of all unvisited vertices
 7     while Q is not empty:                 // The main loop
 8         u := extract_min(Q)               // Remove best vertex from priority queue; returns source on first iteration
 9         for each neighbor v of u:         // where v has not yet been considered
10             alt = dist[u] + length(u, v)
11             if alt < dist[v]              // Relax (u,v)
12                 dist[v] := alt
13                 previous[v] := u
14     return previous[]


//simplification
1 S := empty sequence
2 u := target
3 while defined previous[u]
4     insert u at the beginning of S
5     u := previous[u]

*/
	return NULL;
}
