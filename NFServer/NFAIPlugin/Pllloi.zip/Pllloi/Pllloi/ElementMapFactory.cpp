#include "StdAfx.h"
#include "ElementMapFactory.h"
#include "SimpleWall_EM.h"
#include "Ground_EM.h"


ElementMap ElementMapFactory::buildElementMap(int pType)
{
	switch (pType)
	{
		case ElementMap::SimpleWall :
			return SimpleWall_EM();
		case ElementMap::Ground :
		default:
			return Ground_EM();
		

	}

	return Ground_EM();
}
