#include "StdAfx.h"
#include "PathFinding.h"

PathFinding::PathFinding(MPoint &pStart, MPoint &pGoal, Map &pmap)
{
	Start=pStart;
	Goal=pGoal;
	Mmap=&pmap;
}

PathFinding::~PathFinding(void)
{
}
