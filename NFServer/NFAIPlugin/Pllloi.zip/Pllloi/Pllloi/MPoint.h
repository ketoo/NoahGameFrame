#pragma once

class MPoint
{
private:
	
public:
	int x,y;
	float h,g,f;
	MPoint *Parent;
	MPoint(void);
	MPoint(int x , int y);
	~MPoint(void);
};
