#pragma once
#include "Map.h"
#include "MPoint.h"
#include <vector>
class PathFinding
{
protected :
	MPoint Start;
	MPoint Goal;
	Map *Mmap;
public:
	PathFinding(MPoint &Start, MPoint &Goal, Map &map );
	~PathFinding(void);
	virtual MPoint* calculate() = 0;
};
