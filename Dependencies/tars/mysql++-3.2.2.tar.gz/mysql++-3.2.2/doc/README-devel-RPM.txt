mysql++-devel RPM installs the files you need when building your own
MySQL++ based programs, as well as documentation and examples that
can help you learn how to use the library.

The MySQL++ header files are in /usr/include/mysql++, the library
is in /usr/lib, and the example programs' source code is in
/usr/share/doc/mysql++-devel-*/examples.  For more information on
the examples, see the README-examples.txt file in the directory
containing the examples.

