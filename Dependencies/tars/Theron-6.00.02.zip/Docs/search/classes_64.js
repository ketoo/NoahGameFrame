var searchData=
[
  ['defaultallocator',['DefaultAllocator',['../classTheron_1_1DefaultAllocator.html',1,'Theron']]]
];
