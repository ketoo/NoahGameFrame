var searchData=
[
  ['guard_5fvalue',['GUARD_VALUE',['../classTheron_1_1DefaultAllocator_a9ad5a3063a263e545f3a3c04189b0074.html#a9ad5a3063a263e545f3a3c04189b0074',1,'Theron::DefaultAllocator']]]
];
