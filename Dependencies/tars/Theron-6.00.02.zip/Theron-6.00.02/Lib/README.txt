Theron libraries are built to this folder. 
