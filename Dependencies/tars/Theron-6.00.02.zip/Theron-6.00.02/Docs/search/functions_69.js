var searchData=
[
  ['iallocator',['IAllocator',['../classTheron_1_1IAllocator_ad0c31c6a84b3bf476dae611ac38df1ef.html#ad0c31c6a84b3bf476dae611ac38df1ef',1,'Theron::IAllocator']]],
  ['ishandlerregistered',['IsHandlerRegistered',['../classTheron_1_1Actor_a8b85886531b76f0e6aa9b46004ff6bb0.html#a8b85886531b76f0e6aa9b46004ff6bb0',1,'Theron::Actor']]]
];
