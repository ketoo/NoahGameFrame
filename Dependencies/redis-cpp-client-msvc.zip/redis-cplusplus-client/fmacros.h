#ifndef _REDIS_FMACRO_H
#define _REDIS_FMACRO_H

#define _BSD_SOURCE
#define _XOPEN_SOURCE

#endif
