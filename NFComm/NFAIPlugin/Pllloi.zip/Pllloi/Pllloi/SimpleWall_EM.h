#pragma once
#include "ElementMap.h"
class SimpleWall_EM : public  ElementMap
{
public:
	SimpleWall_EM(void) ;
	~SimpleWall_EM(void);
};
