#pragma once
#include "ElementMap.h"
class Ground_EM  :public  ElementMap
{
public:
	Ground_EM(void);
	~Ground_EM(void);
};
