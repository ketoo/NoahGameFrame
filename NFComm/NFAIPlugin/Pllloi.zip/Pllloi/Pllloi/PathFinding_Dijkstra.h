#pragma once
#include "pathfinding.h"

class PathFinding_Dijkstra :
	public PathFinding
{
public:
	PathFinding_Dijkstra(MPoint &pStart, MPoint &pGoal, Map &pmap ) ;
	~PathFinding_Dijkstra(void);
	MPoint* calculate();
};
