#pragma once
#include "ElementMap.h"
class ElementMapFactory
{
public:
	
	/**
	 * Generate element Map By Type
	 */
	static ElementMap buildElementMap(int Type);
};
