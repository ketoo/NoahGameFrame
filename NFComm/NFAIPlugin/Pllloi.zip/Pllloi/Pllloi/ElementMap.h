#pragma once

class ElementMap
{
public:
	
	/**
	* List of Element Type
	*/
	enum ElementType {Ground,SimpleWall};
	
	int getType();
private:
	int type;
protected : 
	ElementMap (int pType);
	void setType (int pType);
};
