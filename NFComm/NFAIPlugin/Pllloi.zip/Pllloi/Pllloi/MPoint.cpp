#include "StdAfx.h"
#include "MPoint.h"

MPoint::MPoint(void)
{
}

MPoint::MPoint(int px,int py)
{
	x=px;
	y=py;
	f=g=h=0.0f;
	Parent=NULL;
}

MPoint::~MPoint(void)
{
	if (Parent!=NULL)
		delete Parent;
}
