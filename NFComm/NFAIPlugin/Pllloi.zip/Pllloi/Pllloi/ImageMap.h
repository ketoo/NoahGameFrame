#pragma once

class ImageMap
{
public:
	ImageMap(int width, int height);
	~ImageMap(void);
private :
	Bitmap *mBitmap;
};
