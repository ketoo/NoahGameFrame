#pragma once

class MapImageFactory
{
public:
	MapImageFactory(void);
	~MapImageFactory(void);

};
