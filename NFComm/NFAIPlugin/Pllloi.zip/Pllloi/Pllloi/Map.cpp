#include "StdAfx.h"
#include "Map.h"
#include "ElementMapFactory.h"

Map::Map(int pwidth,int pheight)
{
	width=pwidth;
	height=pheight;
	state=EMPTY_MAP;

}

Map::~Map(void)
{
}

ElementMap Map::getElementMap(int x,int y)
{
	long vv=y*width+x;
	if (vv<elementsMap.size())
		return elementsMap[vv];
	else
		return ElementMapFactory::buildElementMap(ElementMap::SimpleWall);
}

bool Map::generateMap()
{
	// If Not Empty, not good idea
	if (state!=EMPTY_MAP)
		return false;
	int i=0;
	int vNBSW=0;
	int vNBGR=0;
	for (i=0;i<width*height;i++)
	{
		//Choose an Element Type
		int ind=rand()%4;
		int choice ;
		switch (ind)
		{
			case 1:
				choice= ElementMap::SimpleWall;
				vNBSW++;
				break;
			case 0: 
			default :
				choice = ElementMap::Ground;
				vNBGR++;
		}
		elementsMap.push_back(ElementMapFactory::buildElementMap(choice));
	}

	return true;

};
