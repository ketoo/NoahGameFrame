#include "StdAfx.h"
#include "ImageMap.h"

ImageMap::ImageMap(   int pWidth,  int pHeight)
{
	mBitmap = new Bitmap(pWidth,pHeight,PixelFormat16bppARGB1555);

	}

ImageMap::~ImageMap(void)
{
	delete mBitmap;
}
