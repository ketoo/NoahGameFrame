#pragma once
#include "PathFinding.h"
#include <vector>
class PathFinding_AStar : public PathFinding
{
private : 
public:
	PathFinding_AStar(MPoint &Start, MPoint &Goal, Map &map );
	~PathFinding_AStar(void);
	MPoint* calculate();
};
