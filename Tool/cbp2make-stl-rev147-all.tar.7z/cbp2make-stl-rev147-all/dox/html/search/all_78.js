var searchData=
[
  ['xmlfriendly',['XMLFriendly',['../d4/d94/cbhelper_8cpp.html#ab99be774bdb63d0883083835fc519647',1,'XMLFriendly(const CString &amp;AString):&#160;cbhelper.cpp'],['../df/dd3/cbhelper_8h.html#a6ea18dc5b132904e5e09373dbb4d5c45',1,'XMLFriendly(const CString &amp;AString):&#160;cbhelper.cpp']]],
  ['xor_5fhash',['xor_hash',['../d6/d7a/stringhash_8cpp.html#a3b9da65bc56c5db07e2f3eb4b344ae04',1,'xor_hash(const data_t *data, const size_t size):&#160;stringhash.cpp'],['../d2/d7f/stringhash_8h.html#ae19fcb0777b65f5eb53c8947ee2ce86c',1,'xor_hash(const data_t *data, const size_t size):&#160;stringhash.cpp']]]
];
